jui.define("chart.widget.polygon.core", [], function() {

    /**
     * @class chart.widget.polygon.core
     * @extends chart.widget.core
     */
    var PolygonCoreWidget = function(chart, axis, widget) {
    }

    return PolygonCoreWidget;
}, "chart.widget.core");